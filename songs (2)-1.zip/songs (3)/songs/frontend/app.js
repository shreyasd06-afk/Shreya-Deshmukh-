const API_KEY = "AIzaSyA3XQ8J9QX5DSN2nPFUKXribgjwG1VJuKk"; // <-- Replace with your YouTube Data API key
const player = document.getElementById("player");
const playlistEl = document.querySelector('#searchResultsList ul'); // Reference the ul inside searchResultsList

let currentIndex = 0;
let songs = [];

// Login Elements
const loginContainer = document.getElementById("loginContainer");
const appContainer = document.getElementById("appContainer");
const usernameInput = document.getElementById("usernameInput");
const passwordInput = document.getElementById("passwordInput");
const loginBtn = document.getElementById("loginBtn");
const loginMessage = document.getElementById("loginMessage");

// Removed: New elements for Spotify-like UI (adjusted for new structure)
// Removed: toggleNavBtn, closeNavBtn, navOverlay

const navHome = document.getElementById('navHome');
const navSearch = document.getElementById('navSearch'); // Placeholder, search functionality not yet implemented
const navSettings = document.getElementById('navSettings'); // New: Settings navigation link
const navLogout = document.getElementById('navLogout'); // Updated: Logout is now a navigation link
// Removed: Podcast related elements
// const navPodcasts = document.getElementById('navPodcasts');
// const podcastsSection = document.getElementById('podcastsSection');
// const podcastListings = document.getElementById('podcastListings');

const homeSection = document.getElementById('homeSection');
const settingsSection = document.getElementById('settingsSection'); // New: Settings section
const navLibrary = document.getElementById('navLibrary');
const navPlaylists = document.getElementById('navPlaylists');
const favoritesSection = document.getElementById('favoritesSection');
const playlistsSection = document.getElementById('playlistsSection');
const favoritesList = document.getElementById('favoritesList');
const playlistsContainer = document.getElementById('playlistsContainer');

const currentSongTitle = document.getElementById('currentSongTitle');
const barPrevBtn = document.getElementById('barPrevBtn');
const barPlayPauseBtn = document.getElementById('barPlayPauseBtn');
const barNextBtn = document.getElementById('barNextBtn');
const volumeSlider = document.querySelector('.volume-slider');

let selectedMood = 'happy'; // Default mood
const moodGraphicsContainer = document.getElementById('moodGraphicsContainer');

// Player elements
const audioPlayer = document.getElementById('audioPlayer');
const videoPlayer = document.getElementById('videoPlayer');
// Removed: podcastCoverArt

let activePlayer = null; // To keep track of the currently active player (audioPlayer or videoPlayer)

// Listen for when the audio player ends a song
audioPlayer.addEventListener('ended', () => {
    // Automatically play the next song/podcast
    if (songs.length > 0) {
        currentIndex = (currentIndex + 1) % songs.length;
        playSong(songs[currentIndex]); // Pass the whole song object
    }
});

// Listen for when the video player ends a song (YouTube embedded player sends messages)
// This is a simplified approach, a full YouTube API integration would be more robust.
// We'll assume playback ends or user navigates.

// Login Functionality
loginBtn.addEventListener('click', () => {
    const username = usernameInput.value;
    const password = passwordInput.value;

    // Simple validation (replace with actual authentication)
    if (username === 'user' && password === 'password') {
        localStorage.setItem('loggedInUser', username);
        checkLoginStatus();
    } else {
        loginMessage.textContent = 'Invalid username or password.';
    }
});

// Updated: Logout event listener for the new navLogout link
navLogout.addEventListener('click', () => {
    localStorage.removeItem('loggedInUser');
    checkLoginStatus();
});

function checkLoginStatus() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    console.log('Current loggedInUser:', loggedInUser);
    if (loggedInUser) {
        console.log('User is logged in. Showing app container.');
        loginContainer.style.display = 'none';
        appContainer.style.display = 'flex'; // Use flex for app container's new layout
        
        // Show welcome animation first
        showWelcomeAnimation();
        
        // Apply initial mood background on login
        applyMoodBackground(selectedMood);
    } else {
        console.log('User is NOT logged in. Showing login container.');
        loginContainer.style.display = 'block';
        appContainer.style.display = 'none';
        usernameInput.value = '';
        passwordInput.value = '';
        loginMessage.textContent = '';
        // Ensure default background is applied when logged out or on initial load
        applyMoodBackground('happy'); // Apply a default mood theme when logged out
    }
}

function showWelcomeAnimation() {
    const welcomeAnimation = document.getElementById('welcomeAnimation');
    const mainHeader = document.getElementById('mainHeader');
    
    // Show welcome animation
    welcomeAnimation.style.display = 'flex';
    mainHeader.style.display = 'none';
    
    // After animation completes, hide welcome and show main content
    setTimeout(() => {
        welcomeAnimation.style.animation = 'welcomeFadeOut 0.8s ease-in-out forwards';
        
        setTimeout(() => {
            welcomeAnimation.style.display = 'none';
            mainHeader.style.display = 'flex';
            showSection('homeSection'); // Show home section after animation
        }, 800);
    }, 3000); // Show animation for 3 seconds
}

// Initial check on page load - Moved to DOMContentLoaded listener below

// Navigation Functionality
function showSection(sectionId) {
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');

    // Update active class on sidebar links
    document.querySelectorAll('.sidebar nav a').forEach(link => {
        link.classList.remove('active');
    });
    const activeLink = document.querySelector(`#nav${sectionId.replace('Section', '')}`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Close nav overlay after selection - REMOVED as overlay is gone
    // navOverlay.classList.remove('active');
}

// Event listeners for navigation links within the sidebar
document.getElementById('navHome').addEventListener('click', (e) => {
    e.preventDefault();
    // Navigate to home section instead of refreshing
    showSection('homeSection');
});

document.getElementById('navSearch').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('searchSection');
});

document.getElementById('navSettings').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('settingsSection');
});

document.getElementById('navLibrary').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('favoritesSection'); // Show favorites section for 'My Library'
    renderFavorites();
});

document.getElementById('navPlaylists').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('playlistsSection');
    renderPlaylists();
});

// Search button click
document.getElementById("searchBtn").addEventListener("click", async () => {
    await fetchSongs();
});

// Clear search button click
document.getElementById("clearSearchBtn").addEventListener("click", () => {
    clearSearch();
});

// Clear history button click
document.getElementById("clearHistoryBtn").addEventListener("click", () => {
    clearSearchHistory();
});

// Clear song history button click
document.getElementById("clearSongHistoryBtn").addEventListener("click", () => {
    clearSongHistory();
});

// Search on Enter key press
document.getElementById("searchQuery").addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
        fetchSongs();
    }
});

// Search section event listeners
document.getElementById("searchQuerySearch")?.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
        fetchSongsFromSearch();
    }
});

document.getElementById("searchBtnSearch")?.addEventListener("click", async () => {
    await fetchSongsFromSearch();
});

document.getElementById("clearSearchBtnSearch")?.addEventListener("click", () => {
    clearSearchSection();
});

// Create playlist modal event listeners
document.getElementById("createPlaylistBtn")?.addEventListener("click", () => {
    openCreatePlaylistModal();
});

document.getElementById("closeModalBtn")?.addEventListener("click", () => {
    closeCreatePlaylistModal();
});

document.getElementById("cancelPlaylistBtn")?.addEventListener("click", () => {
    closeCreatePlaylistModal();
});

document.getElementById("savePlaylistBtn")?.addEventListener("click", () => {
    createNewPlaylist();
});

// Function to clear search and reset interface
function clearSearch() {
    document.getElementById("searchQuery").value = '';
    document.getElementById("artist").value = '';
    document.getElementById("language").value = '';
    
    // Clear search results
    if (playlistEl) {
        playlistEl.innerHTML = '<p>Search for songs, artists, or genres to get started! 🎵</p>';
    }
    
    // Reset songs array
    songs = [];
    currentIndex = 0;
    
    // Reset player display
    currentSongTitle.textContent = 'No song playing';
    
    // Hide players
    if (audioPlayer) audioPlayer.style.display = 'none';
    if (videoPlayer) videoPlayer.style.display = 'none';
    
    // Reset to default mood background
    selectedMood = 'happy';
    applyMoodBackground(selectedMood);
}

function clearSearchHistory() {
    searchHistory = [];
    saveSearchHistory();
    renderSearchHistory();
}

function clearSongHistory() {
    songHistory = [];
    saveSongHistory();
    renderSongHistory();
}

// Search section functions
function fetchSongsFromSearch() {
    const searchQuery = document.getElementById("searchQuerySearch").value.trim();
    const artist = document.getElementById("artistSearch").value;
    const language = document.getElementById("languageSearch").value;
    
    if (!searchQuery) {
        alert("Please enter a search term!");
        return;
    }
    
    // Use the existing fetchSongs function but with search section inputs
    const originalSearchQuery = document.getElementById("searchQuery");
    const originalArtist = document.getElementById("artist");
    const originalLanguage = document.getElementById("language");
    
    // Temporarily set the main search inputs
    originalSearchQuery.value = searchQuery;
    originalArtist.value = artist;
    originalLanguage.value = language;
    
    // Perform the search
    fetchSongs();
    
    // Clear the search section inputs
    document.getElementById("searchQuerySearch").value = '';
    document.getElementById("artistSearch").value = '';
    document.getElementById("languageSearch").value = '';
}

function clearSearchSection() {
    document.getElementById("searchQuerySearch").value = '';
    document.getElementById("artistSearch").value = '';
    document.getElementById("languageSearch").value = '';
    
    // Clear search results in search section
    const searchPlaylist = document.getElementById('searchPlaylist');
    if (searchPlaylist) {
        searchPlaylist.innerHTML = '<p>Search for songs to get started! 🎵</p>';
    }
}

// Create playlist modal functions
function openCreatePlaylistModal() {
    const modal = document.getElementById('createPlaylistModal');
    modal.style.display = 'block';
    
    // Clear previous input
    document.getElementById('playlistName').value = '';
    document.getElementById('playlistDescription').value = '';
}

function closeCreatePlaylistModal() {
    const modal = document.getElementById('createPlaylistModal');
    modal.style.display = 'none';
}

function createNewPlaylist() {
    const name = document.getElementById('playlistName').value.trim();
    const description = document.getElementById('playlistDescription').value.trim();
    
    if (!name) {
        alert('Please enter a playlist name!');
        return;
    }
    
    if (playlists[name]) {
        alert('A playlist with this name already exists!');
        return;
    }
    
    // Create new playlist
    playlists[name] = {
        description: description,
        songs: [],
        createdAt: new Date().toISOString()
    };
    
    savePlaylists();
    renderPlaylists();
    closeCreatePlaylistModal();
    
    alert(`Playlist "${name}" created successfully!`);
}

// Mood change is now handled by mood card clicks, no need for select change listener

// Controls
barPrevBtn.addEventListener("click", () => {
    if (songs.length > 0) {
        currentIndex = (currentIndex - 1 + songs.length) % songs.length;
        playSong(songs[currentIndex]); // Pass the whole song object
    }
});

barNextBtn.addEventListener("click", () => {
    if (songs.length > 0) {
        currentIndex = (currentIndex + 1) % songs.length;
        playSong(songs[currentIndex]); // Pass the whole song object
    }
});

// Shuffle button functionality (can be added to player bar if desired)
document.getElementById("shuffleBtn").addEventListener("click", () => {
    if (songs.length > 0) {
        currentIndex = Math.floor(Math.random() * songs.length);
        playSong(songs[currentIndex]); // Pass the whole song object
    }
});

barPlayPauseBtn.addEventListener('click', () => {
    if (activePlayer && activePlayer.paused) {
        activePlayer.play();
        barPlayPauseBtn.textContent = '⏸';
    } else if (activePlayer) {
        activePlayer.pause();
        barPlayPauseBtn.textContent = '▶';
    }
});

// Workout button event listener
document.getElementById('workoutSearchBtn')?.addEventListener('click', async () => {
    selectedMood = 'workout';
    applyMoodBackground(selectedMood);
    await fetchSongs();
    showSection('homeSection');
});

// Fetch songs from YouTube
async function fetchSongs() {
    const searchQuery = document.getElementById("searchQuery").value.trim();
    const artist = document.getElementById("artist").value;
    const language = document.getElementById("language").value;
    
    let query;
    
    // If user has entered a specific search query, use that
    if (searchQuery) {
        query = searchQuery;
        if (artist) {
            query += ` by ${artist}`;
        }
    } else {
        // Fall back to mood-based search if no specific query
        const mood = selectedMood;
        query = artist ? `${mood} songs by ${artist}` : `${mood} songs`;
    }

    if (language) {
        query += ` in ${language}`;
    }

    // For YouTube, the "videoId" is not a direct audio URL, so we need to handle it differently
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&type=video&videoEmbeddable=true&q=${encodeURIComponent(query)}&key=${API_KEY}`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.items) {
            songs = data.items.map(item => ({
                title: item.snippet.title,
                videoId: item.id.videoId, // Store only the video ID
                type: 'video' // Mark as video
            }));

            renderPlaylist(songs); // Pass songs to renderPlaylist
            currentIndex = 0;
            playSong(songs[0]); // Pass the whole song object
            
            // Add to search history
            addToSearchHistory(searchQuery, artist, language);
        } else {
            alert("No songs found!");
        }
    } catch (error) {
        console.error("Error fetching YouTube data:", error);
        alert("Error fetching songs. Check your API key or quota.");
    }
}

// Play song - now handles both YouTube embeds and direct audio URLs
function playSong(song) {
    // Hide all players and cover art first
    audioPlayer.style.display = 'none';
    videoPlayer.style.display = 'none';
    // Removed: podcastCoverArt hide
    // podcastCoverArt.style.display = 'none'; // Hide cover art
    audioPlayer.pause(); // Pause audio player if playing
    audioPlayer.src = ''; // Clear audio source
    videoPlayer.src = ''; // Clear video source

    if (song.type === 'video') {
        activePlayer = videoPlayer;
        videoPlayer.style.display = 'block';
        videoPlayer.src = `https://www.youtube.com/embed/${song.videoId}?autoplay=1`;
    } else if (song.type === 'audio') {
        activePlayer = audioPlayer;
        audioPlayer.style.display = 'block';
        audioPlayer.src = song.videoId; // videoId now holds the audio URL
        audioPlayer.play();
        // Removed: podcastCoverArt handling
        // if (song.imageUrl) {
        //     podcastCoverArt.src = song.imageUrl;
        //     podcastCoverArt.style.display = 'block';
        // }
    } else {
        console.error("Unknown song type:", song);
        return; // Don't proceed if type is unknown
    }

    barPlayPauseBtn.textContent = '⏸'; // Always set to pause, assuming playback starts
    // The global `player` variable should now refer to the activePlayer
    // Since `player` is still defined, we should ensure it points to the current active player.
    // For simplicity, let's manage controls via activePlayer directly.

    highlightCurrentSong();
    const songTitle = songs[currentIndex] ? songs[currentIndex].title : 'No song playing';
    currentSongTitle.textContent = songTitle;
    
    // Add to song history when a song starts playing
    if (song) {
        addToSongHistory(song);
    }
}

// Render playlist - This function is now for displaying search results in the Home section
function renderPlaylist(songsToRender) {
    playlistEl.innerHTML = ''; // playlistEl is now the ul inside the Home section's player section
    if (!songsToRender || songsToRender.length === 0) {
        playlistEl.innerHTML = '<p>No songs found. Try a different search term!</p>';
        return;
    }
    songsToRender.forEach((song, index) => {
        const li = document.createElement('li');
        li.className = 'playlist-item';
        li.innerHTML = `
            <div>
                <h3>${song.title}</h3>
            </div>
        `;
        li.addEventListener('click', () => {
            currentIndex = index;
            playSong(song); // Pass the whole song object
        });
        playlistEl.appendChild(li);
    });
}

// Highlight current playing song
function highlightCurrentSong() {
    // Remove highlight from previous songs across all lists
    document.querySelectorAll('.playlist-item').forEach(item => {
        item.classList.remove('active-song');
    });

    // Add highlight to current song if it exists in the currently rendered list
    // This part might need refinement based on how you manage 'songs' array for different sections
    const currentSongElement = playlistEl.querySelector(`li:nth-child(${currentIndex + 1})`);
    if (currentSongElement) {
        currentSongElement.classList.add('active-song');
    }

    // For Favorites and Playlists sections, you'll need similar logic
    // Example for Favorites (assuming renderFavorites is called and has similar list items)
    if (favoritesSection.classList.contains('active')) {
        const favSongElement = favoritesList.querySelector(`li:nth-child(${currentIndex + 1})`);
        if (favSongElement) favSongElement.classList.add('active-song');
    }

    // if (playlistsSection.classList.contains('active')) {
    //     // This is more complex as playlistsContainer holds multiple lists
    //     // You'd need to find the currently active playlist and then its song
    //     // For simplicity, we'll skip detailed highlight for nested playlists for now.
    //     // You can implement this as an enhancement later if needed.
    // }
}

// Volume Control (moved up for global access)
if (volumeSlider) {
    // Set initial volume to 50% to avoid sudden loud audio

    // Initialize volume for both players
    audioPlayer.volume = 0.5;
    videoPlayer.volume = 0.5; // YouTube player controls its own volume, but this can be a reference
    volumeSlider.value = 50;

    volumeSlider.addEventListener('input', (e) => {
        if (activePlayer) {
            activePlayer.volume = e.target.value / 100;
        }
    });
}

// Mood-based gradient backgrounds
const moodGradients = {
    happy: 'linear-gradient(135deg, #FFEFBA, #FFFFFF)', // Light Yellow to White
    sad: 'linear-gradient(135deg, #CFD9ED, #E2EBF6)',   // Light Blue to Lighter Blue
    romantic: 'linear-gradient(135deg, #FFEBEB, #FFC0CB)', // Pale Pink to Light Pink
    energetic: 'linear-gradient(135deg, #FFFDEB, #FFECB3)', // Very Light Yellow to Light Orange
    chill: 'linear-gradient(135deg, #E0F2F7, #B2EBF2)',    // Light Cyan to Paler Cyan
    workout: 'linear-gradient(135deg, #32CD32, #228B22)'  // Green to Dark Green for workout mood
};

function applyMoodBackground(mood) {
    const gradient = moodGradients[mood] || moodGradients.happy; // Default to happy if mood not found
    document.body.style.background = gradient;
    document.body.style.backgroundSize = '300% 300%'; // Ensure gradient animation effect
    document.body.style.animation = 'gradientAnimation 25s ease infinite'; // Re-apply animation

    // Update mood graphics
    moodGraphicsContainer.className = 'mood-graphics-container'; // Reset classes
    moodGraphicsContainer.classList.add(mood); // Add current mood class

    // Apply mood-specific theme to the app container
    appContainer.className = 'app-container'; // Reset classes
    appContainer.classList.add(`mood-${mood}`); // Add mood-specific class
}

// Define the gradient animation keyframes in JS (or ensure they are in CSS)
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = `
    @keyframes gradientAnimation {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
`;
document.head.appendChild(styleSheet);

// Event Listeners (updated to use new navigation elements)
document.addEventListener('DOMContentLoaded', () => {
    checkLoginStatus();
    loadFavorites();
    loadPlaylists();
    // Always render histories regardless of login status
    renderSearchHistory();
    renderSongHistory();
    // Removed: fetchAndRenderPodcasts() as podcasts section is removed
    // Apply initial mood background on load (only if logged in or a default is desired)
    // This part is now handled by checkLoginStatus itself
});

// Favorites and Playlists
const addFavoriteBtn = document.getElementById("addFavoriteBtn");
const addPlaylistBtn = document.getElementById("addPlaylistBtn");

let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
let playlists = JSON.parse(localStorage.getItem('playlists')) || {};
let searchHistory = JSON.parse(localStorage.getItem('searchHistory')) || [];
let songHistory = JSON.parse(localStorage.getItem('songHistory')) || [];

function saveFavorites() {
    localStorage.setItem('favorites', JSON.stringify(favorites));
}

function savePlaylists() {
    localStorage.setItem('playlists', JSON.stringify(playlists));
}

function saveSearchHistory() {
    localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
}

function saveSongHistory() {
    localStorage.setItem('songHistory', JSON.stringify(songHistory));
}

function addToSearchHistory(query, artist = '', language = '') {
    const historyItem = {
        query: query,
        artist: artist,
        language: language,
        timestamp: new Date().toISOString(),
        displayText: query + (artist ? ` by ${artist}` : '') + (language ? ` (${language})` : '')
    };
    
    // Remove duplicate entries
    searchHistory = searchHistory.filter(item => 
        item.query !== query || item.artist !== artist || item.language !== language
    );
    
    // Add new item at the beginning
    searchHistory.unshift(historyItem);
    
    // Keep only last 10 searches
    if (searchHistory.length > 10) {
        searchHistory = searchHistory.slice(0, 10);
    }
    
    saveSearchHistory();
    renderSearchHistory();
}

function addToSongHistory(song) {
    const historyItem = {
        title: song.title,
        videoId: song.videoId,
        type: song.type,
        timestamp: new Date().toISOString(),
        searchContext: selectedMood || 'custom search'
    };
    
    // Remove duplicate entries (same song)
    songHistory = songHistory.filter(item => item.videoId !== song.videoId);
    
    // Add new item at the beginning
    songHistory.unshift(historyItem);
    
    // Keep only last 20 songs
    if (songHistory.length > 20) {
        songHistory = songHistory.slice(0, 20);
    }
    
    saveSongHistory();
    renderSongHistory();
}

function renderSearchHistory() {
    const historyContainer = document.getElementById('searchHistory');
    if (!historyContainer) return;
    
    if (searchHistory.length === 0) {
        historyContainer.innerHTML = '<p style="color: var(--text-secondary); font-style: italic;">No search history yet. Start searching to build your history!</p>';
        return;
    }
    
    historyContainer.innerHTML = '';
    searchHistory.forEach((item, index) => {
        const tag = document.createElement('div');
        tag.className = 'history-tag';
        tag.innerHTML = `
            <span class="tag-icon">🔍</span>
            <span>${item.displayText}</span>
            <span class="tag-time">${formatTimeAgo(item.timestamp)}</span>
        `;
        
        tag.addEventListener('click', () => {
            // Fill the search fields with history data
            document.getElementById('searchQuery').value = item.query;
            document.getElementById('artist').value = item.artist;
            document.getElementById('language').value = item.language;
            
            // Perform the search
            fetchSongs();
        });
        
        historyContainer.appendChild(tag);
    });
}

function formatTimeAgo(timestamp) {
    const now = new Date();
    const past = new Date(timestamp);
    const diffInMinutes = Math.floor((now - past) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
}

function renderSongHistory() {
    const historyContainer = document.getElementById('songHistory');
    if (!historyContainer) return;
    
    if (songHistory.length === 0) {
        historyContainer.innerHTML = '<p style="color: var(--text-secondary); font-style: italic;">No songs played yet. Start listening to build your history!</p>';
        return;
    }
    
    historyContainer.innerHTML = '';
    songHistory.forEach((item, index) => {
        const historyItem = document.createElement('div');
        historyItem.className = 'song-history-item';
        
        // Check if this song is currently playing
        if (songs[currentIndex] && songs[currentIndex].videoId === item.videoId) {
            historyItem.classList.add('playing');
        }
        
        historyItem.innerHTML = `
            <div class="song-info">
                <div class="song-title">${item.title}</div>
                <div class="song-meta">
                    <span>${item.searchContext}</span>
                    <span>•</span>
                    <span>${item.type}</span>
                </div>
            </div>
            <div class="song-time">${formatTimeAgo(item.timestamp)}</div>
            <div class="play-icon">▶</div>
        `;
        
        historyItem.addEventListener('click', () => {
            // Create a song object and play it
            const songToPlay = {
                title: item.title,
                videoId: item.videoId,
                type: item.type
            };
            
            // Add to current songs array for playback control
            songs = [songToPlay];
            currentIndex = 0;
            
            // Play the song
            playSong(songToPlay);
            
            // Update the display
            renderPlaylist(songs);
            highlightCurrentSong();
        });
        
        historyContainer.appendChild(historyItem);
    });
}

function renderFavorites() {
    favoritesList.innerHTML = '';
    if (favorites.length === 0) {
        favoritesList.innerHTML = '<p>No liked songs yet. Add some from the home section!</p>';
        return;
    }
    favorites.forEach((song, index) => {
        const li = document.createElement('li');
        li.className = 'playlist-item'; // Using generic playlist-item class for styling
        li.innerHTML = `
            <div>
                <h3>${song.title}</h3>
            </div>
        `;
        li.addEventListener('click', () => {
            playSong(song); // Pass the whole song object
            // You might want to temporarily add this to the 'songs' array for playback controls
            songs = favorites; // Play from favorites list
            currentIndex = index;
        });
        favoritesList.appendChild(li);
    });
}

function renderPlaylists() {
    playlistsContainer.innerHTML = '';
    const playlistNames = Object.keys(playlists);
    if (playlistNames.length === 0) {
        playlistsContainer.innerHTML = '<p style="color: var(--text-secondary); font-style: italic;">No playlists created yet. Create your first playlist to get started!</p>';
        return;
    }

    playlistNames.forEach(name => {
        const playlist = playlists[name];
        const playlistDiv = document.createElement('div');
        playlistDiv.className = 'playlist-card';
        playlistDiv.innerHTML = `
            <div class="playlist-header">
                <h3>${name}</h3>
                <span class="playlist-count">${playlist.songs ? playlist.songs.length : 0} songs</span>
            </div>
            ${playlist.description ? `<p class="playlist-description">${playlist.description}</p>` : ''}
            <div class="playlist-actions">
                <button class="play-playlist-btn" data-playlist="${name}">▶ Play All</button>
                <button class="delete-playlist-btn" data-playlist="${name}">🗑️ Delete</button>
            </div>
            ${playlist.songs && playlist.songs.length > 0 ? `<ul class="playlist-card-songs"></ul>` : '<p class="no-songs">No songs in this playlist yet.</p>'}
        `;
        
        // Add event listeners for playlist actions
        const playBtn = playlistDiv.querySelector('.play-playlist-btn');
        const deleteBtn = playlistDiv.querySelector('.delete-playlist-btn');
        
        playBtn.addEventListener('click', () => {
            if (playlist.songs && playlist.songs.length > 0) {
                songs = playlist.songs;
                currentIndex = 0;
                playSong(songs[0]);
                renderPlaylist(songs);
                highlightCurrentSong();
            } else {
                alert('This playlist is empty!');
            }
        });
        
        deleteBtn.addEventListener('click', () => {
            if (confirm(`Are you sure you want to delete the playlist "${name}"?`)) {
                delete playlists[name];
                savePlaylists();
                renderPlaylists();
            }
        });
        
        // Render songs if they exist
        if (playlist.songs && playlist.songs.length > 0) {
            const ul = playlistDiv.querySelector('.playlist-card-songs');
            playlist.songs.forEach((song, index) => {
                const li = document.createElement('li');
                li.className = 'playlist-song-item';
                li.innerHTML = `
                    <span class="song-title">${song.title}</span>
                    <button class="remove-song-btn" data-playlist="${name}" data-index="${index}">×</button>
                `;
                
                li.addEventListener('click', (e) => {
                    if (!e.target.classList.contains('remove-song-btn')) {
                        playSong(song);
                        songs = playlist.songs;
                        currentIndex = index;
                        renderPlaylist(songs);
                        highlightCurrentSong();
                    }
                });
                
                // Remove song from playlist
                const removeBtn = li.querySelector('.remove-song-btn');
                removeBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (confirm(`Remove "${song.title}" from "${name}"?`)) {
                        playlist.songs.splice(index, 1);
                        savePlaylists();
                        renderPlaylists();
                    }
                });
                
                ul.appendChild(li);
            });
        }
        
        playlistsContainer.appendChild(playlistDiv);
    });
}

addFavoriteBtn.addEventListener('click', () => {
    if (songs.length > 0) {
        const currentSong = songs[currentIndex];
        if (!favorites.some(fav => fav.videoId === currentSong.videoId)) {
            favorites.push(currentSong);
            saveFavorites();
            alert(`${currentSong.title} added to favorites!`);
        } else {
            alert(`${currentSong.title} is already in favorites.`);
        }
    }
});

addPlaylistBtn.addEventListener('click', () => {
    if (songs.length > 0) {
        const currentSong = songs[currentIndex];
        showAddToPlaylistModal(currentSong);
    }
});

function showAddToPlaylistModal(song) {
    // Create modal HTML
    const modalHTML = `
        <div id="addToPlaylistModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Add to Playlist</h3>
                    <button class="close-modal-btn" onclick="closeAddToPlaylistModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Add "${song.title}" to:</p>
                    <div class="playlist-selection">
                        <div class="existing-playlists">
                            <h4>Existing Playlists:</h4>
                            <div id="existingPlaylistsList"></div>
                        </div>
                        <div class="create-new-playlist">
                            <h4>Or Create New:</h4>
                            <input type="text" id="newPlaylistName" placeholder="Enter new playlist name">
                            <textarea id="newPlaylistDescription" placeholder="Description (optional)"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="createNewPlaylistBtn" class="save-playlist-btn">Create & Add</button>
                    <button class="cancel-playlist-btn" onclick="closeAddToPlaylistModal()">Cancel</button>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Show modal
    document.getElementById('addToPlaylistModal').style.display = 'block';
    
    // Populate existing playlists
    renderExistingPlaylistsForSelection(song);
    
    // Add event listeners
    document.getElementById('createNewPlaylistBtn').addEventListener('click', () => {
        createNewPlaylistAndAddSong(song);
    });
}

function renderExistingPlaylistsForSelection(song) {
    const container = document.getElementById('existingPlaylistsList');
    const playlistNames = Object.keys(playlists);
    
    if (playlistNames.length === 0) {
        container.innerHTML = '<p style="color: var(--text-secondary); font-style: italic;">No playlists exist yet.</p>';
        return;
    }
    
    playlistNames.forEach(name => {
        const playlist = playlists[name];
        const isAlreadyInPlaylist = playlist.songs && playlist.songs.some(s => s.videoId === song.videoId);
        
        const playlistItem = document.createElement('div');
        playlistItem.className = 'playlist-selection-item';
        playlistItem.innerHTML = `
            <div class="playlist-info">
                <span class="playlist-name">${name}</span>
                <span class="playlist-song-count">${playlist.songs ? playlist.songs.length : 0} songs</span>
            </div>
            <button class="add-to-playlist-btn ${isAlreadyInPlaylist ? 'disabled' : ''}" 
                    data-playlist="${name}" 
                    ${isAlreadyInPlaylist ? 'disabled' : ''}>
                ${isAlreadyInPlaylist ? '✓ Added' : 'Add'}
            </button>
        `;
        
        if (!isAlreadyInPlaylist) {
            playlistItem.querySelector('.add-to-playlist-btn').addEventListener('click', () => {
                addSongToExistingPlaylist(name, song);
            });
        }
        
        container.appendChild(playlistItem);
    });
}

function addSongToExistingPlaylist(playlistName, song) {
    if (!playlists[playlistName]) {
        playlists[playlistName] = { songs: [], description: '', createdAt: new Date().toISOString() };
    }
    
    if (!playlists[playlistName].songs) {
        playlists[playlistName].songs = [];
    }
    
    if (!playlists[playlistName].songs.some(s => s.videoId === song.videoId)) {
        playlists[playlistName].songs.push(song);
        savePlaylists();
        alert(`${song.title} added to playlist "${playlistName}"!`);
        closeAddToPlaylistModal();
    } else {
        alert(`${song.title} is already in playlist "${playlistName}".`);
    }
}

function createNewPlaylistAndAddSong(song) {
    const name = document.getElementById('newPlaylistName').value.trim();
    const description = document.getElementById('newPlaylistDescription').value.trim();
    
    if (!name) {
        alert('Please enter a playlist name!');
        return;
    }
    
    if (playlists[name]) {
        alert('A playlist with this name already exists!');
        return;
    }
    
    // Create new playlist
    playlists[name] = {
        description: description,
        songs: [song],
        createdAt: new Date().toISOString()
    };
    
    savePlaylists();
    renderPlaylists();
    alert(`Playlist "${name}" created and "${song.title}" added!`);
    closeAddToPlaylistModal();
}

function closeAddToPlaylistModal() {
    const modal = document.getElementById('addToPlaylistModal');
    if (modal) {
        modal.remove();
    }
}

// Add event listeners for mood cards
document.addEventListener('DOMContentLoaded', function() {
    const moodCards = document.querySelectorAll('.mood-card');
    
    moodCards.forEach(card => {
        card.addEventListener('click', function() {
            selectedMood = this.getAttribute('data-mood');
            applyMoodBackground(selectedMood);
            fetchSongs();
        });
    });
});
    