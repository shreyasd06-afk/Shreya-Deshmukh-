import os, json
from flask import Flask, request, jsonify
from flask_cors import CORS
from transformers import pipeline
from mapping import text_to_mood, ALLOWED_MOODS

app = Flask(__name__)
CORS(app)

# Load songs
with open(os.path.join(os.path.dirname(__file__), "songs.json"), "r", encoding="utf-8") as f:
    SONGS = json.load(f)

# Lazy-load the sentiment model once
NLP = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/text-mood")
def text_mood():
    data = request.get_json(force=True)
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify({"error": "text is required"}), 400
    res = NLP(text)[0]  # {'label': 'POSITIVE'|'NEGATIVE', 'score': float}
    decision = text_to_mood(res["label"], float(res["score"]), text)
    return jsonify({"mood": decision.mood, "confidence": decision.confidence})

@app.get("/api/recommend")
def recommend():
    mood = request.args.get("mood", "").strip().lower()
    artist = (request.args.get("artist") or "").strip().lower()
    if mood not in ALLOWED_MOODS:
        return jsonify({"error": f"mood must be one of {ALLOWED_MOODS}"}), 400

    pool = SONGS.get(mood, [])
    if artist:
        pool = [s for s in pool if artist in s["artist"].lower()]

    # Fallback: if artist filter empties results, return unfiltered mood pool
    if not pool:
        pool = SONGS.get(mood, [])

    return jsonify({"results": pool, "count": len(pool)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
